const discord = require('discord.js');
const bot = new discord.Client();
const fs = require('fs');
const ytdl = require('ytdl-core');
let config = require('./botconfig.json');
let token = config.token;
let prefix = config.prefix;
let news = 'Новости'; // ПЕРЕМЕННАЯ ДЛЯ НОВОСТЕЙ
let badWords = []; // СООБЩЕНИЯ, ЗА КОТОРЫЕ БОТ ВЫДАЕТ ВАРН/БАН

bot.on('ready', () => {
  console.log('>_ Bot has been started');
  bot.generateInvite(["ADMINISTRATOR"]).then(link => {
    console.log(link);
  });
});
//ОСНОВНАЯ ЛОГИКА БОТА
bot.on('message',  msg => {
  if(msg.content === `${prefix}ping`) {
    msg.channel.send('pong');
  }
  //КИК ЮЗЕРА
  if(msg.content.startsWith('!kick')) {
    const user = msg.mentions.users.first();
    if(user) {
      const member = msg.guild.member(user);
      if(member) {
        member
        .kick('asgag')
        .then(() => {
          msg.channel.send(`Kicked ${user.tag}`);
        })
        .catch(err => {
          msg.channel.send('I was unable to kick the member');
          console.error(err);
        });
      } else {
        msg.channel.send("That user isn't in this guild!");
      }
    } else {
      msg.channel.send("You didn't metion the user to kick!");
    }
  }
//БАН ЮЗЕРА
  if(msg.content.startsWith('!ban')) {
    const user = msg.mentions.users.first();

    if(user) {
      const member = msg.guild.member(user);

      if(member) {
        member
        .ban({
          reason: 'Причина бана',
        })
        .then(() => {
          msg.channel.send(`Banned ${user.tag}`);
        })
        .catch(err => {
          msg.channel.send('I was unable to ban the member');
          console.error(err);
        });
      } else {
        msg.channel.send("That user isn't in this guild!");
      }
    } else {
      msg.channel.send("You didn't mention the user to ban!");
    }
  }
  //ПРИВЕТСВТИЕ НОВОГО ЧЕЛОВЕКА НА СЕРВЕРЕ
  bot.on('guildMemberAdd', member => {
    const channel = member.guild.channels.cache
                          .find(ch => ch.name === 'member-log');

    if(!channel) {
      console.error('Unfounded channel');

      channel.send(`Welcome to the server, ${member}`);
    }
  });
});
bot.login(token);
