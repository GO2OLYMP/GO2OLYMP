const Discord = require('discord.js');
const client = new Discord.Client();
const { Client, MessageEmbed } = require('discord.js')
let prefix = "!!";

const activities_list = [
    "bookstudio.xyz/ bot link",
    "UPDATE 1.6666666666666666666666 YA",
    ];

client.once('ready', () => {
    console.log('какойто болт - запустился удачно.');
    client.generateInvite(["ADMINISTRATOR"]).then(link => {
            console.log("[-] Добавить бота на сервер: " + link);
            client.user.setPresence({status: 'dnd', game:{name: 'test', type: 0}})
            setInterval(() => {
    const index = Math.floor(Math.random() * (activities_list.length - 1) + 1);
    client.user.setActivity(activities_list[index], {
    type: "WATCHING"
    });
    }, 2000);
        });
    });

client.on("message", message => {
    if(!message.guild) return;
    if(message.author === client.user) return;
    if(!message.content.startsWith("!!"))return;
    const args = message.content.slice(prefix.length).trim().split(/ +/g);
    const guild = client.guilds.cache.get(message.guild.id);

if(message.content.startsWith(prefix + "createmute")) {
	if(!message.member.hasPermission("ADMINISTRATOR"))return(message.channel.send("Нет прав."))
message.guild.roles.create({ data: { name: 'Замучен', permissions: 0, color: '777777' } });
            .then(r => role = r).catch(err => {
                return message.channel.send(new Discord.MessageEmbed()
                    .setColor(0xff0000)
                    .setDescription('Произошла ошибка при создании замученной роли, пожалуйста, создайте ее вручную.\n**Желательно сообщить об этом баге: vk.me/danielfonov**')
                );
            });
			message.channel.send('Роль для мутов была создана. Проверь.');
}
///////////////
// Мут коман //
///////////////

if(message.content.startsWith(prefix + "mute")) {
	if(!message.member.hasPermission("MUTE_MEMBERS"))return(message.channel.send(noperms))
let role = message.guild.roles.cache.find(r => r.name == 'Замучен');
if(!role)return(message.channel.send("Не найдена роль `Замучен`. Добавить её -> !!createmute (вам нужно её настроить самостоятельно)"))
	const logchannel = message.guild.channels.cache.find(ch => ch.name === 'logs');
if(!logchannel)return(message.channel.send("Не вижу канала `logs`. Пожалуйста, добавьте этот канал для продолжения работы."))

    let target = message.mentions.members.first();
    if(!target) {
        return message.channel.send(new Discord.MessageEmbed()
            .setColor(f7e300)
            .setDescription('Ошибка! Вы не указали пользователя!')
        );
    }
let reason = args.splice(2).join(" ")

    target.roles.add(role).then(() => {
        message.channel.send(new Discord.MessageEmbed()
            .setColor(f7e300)
            .setDescription(`Пользователь ${target.user.tag} успешно замучен!\nПричина мута: **${reason}**.`)
        );
    }).catch(err => {
        message.channel.send(new Discord.MessageEmbed()
            .setColor(f7e300)
            .setDescription(`Не удалось замутить пользователя :(`)
        );
    });
	const LogMute = new MessageEmbed()
.setTitle(`Модератор ${message.author.tag} замутил нарушителя ${target.user.tag}.`)
.setDescription(`Модератор указал причину мута: **${reason}**\nМут был выдан неверно? Запроси у него доказательства.`)
.setColor("#bfbcb4")

const LogMuteDirect = new MessageEmbed()
.setTitle(`Модератор ${message.author.tag} выдал тебе мут на сервере ${guild.name}`)
.setDescription(`Модератор указал причину мута: **${reason}**\nНегоже тебе нарушать правила.`)
.setColor("#bfbcb4")
logchannel.send(LogMute)
target.send(LogMuteDirect)
}

if(message.content.startsWith(prefix + "unmute")) {
	if(!message.member.hasPermission("MUTE_MEMBERS"))return(message.channel.send(noperms))
		const logchannel = message.guild.channels.cache.find(ch => ch.name === 'logs');
if(!logchannel)return(message.channel.send("Не вижу канала `logs`. Пожалуйста, добавьте этот канал для продолжения работы.новлен обычный канал `logs`."))
	let target = message.mentions.members.first();
	let role = message.guild.roles.cache.find(r => r.name == 'Замучен');
	target.roles.remove(role)
	message.channel.send(new Discord.MessageEmbed()
            .setColor("f7e300")
            .setDescription(`Пользователь ${target.user.tag} успешно размучен!`)
        );
	const LogunMute = new MessageEmbed()
.setTitle(`Модератор ${message.author.tag} размутил нарушителя ${target.user.tag}.`)
.setDescription(`Размут был выдан неверно? Запроси у него доказательства.`)
.setColor("#bfbcb4")


const LogUnMuteDirect = new MessageEmbed()
.setTitle(`Модератор ${message.author.tag} выдал тебе размут на сервере ${guild.name}`)
.setDescription(`Поздравляю.`)
.setColor("#bfbcb4")
target.send(LogUnMuteDirect)
logchannel.send(LogunMute)
}
});
